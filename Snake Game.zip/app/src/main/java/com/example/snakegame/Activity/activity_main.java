package com.example.snakegame.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.snakegame.R;

public class activity_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}